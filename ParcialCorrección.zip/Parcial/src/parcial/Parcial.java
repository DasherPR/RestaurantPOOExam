/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package parcial;
import java.util.Scanner;

/**
 *
 * @author camil
 */
public class Parcial {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      Usuario user = new Usuario();
      Scanner input = new Scanner(System.in);
      Mesa mesa1 = new Mesa(1);
      
      // lista de productos
      Comida arepas = new Comida("Entrada","Arepas",10000f);
      Comida papasfritas = new Comida("Entrada","Papas Fritas",12000f);
      Comida nachos = new Comida("Entrada","Nachos",10000f);
      Comida churrasco = new Comida("Plato Fuerte","Churrasco",25000f);
      Comida pollofrito = new Comida("Plato Fuerte","Pollo Frito",20000f);
      Comida arrozoriental = new Comida("Plato Fuerte","Arroz Oriental",21500f);
      Comida limonada = new Comida("Bebida","Limonada",5000f);
      Comida gaseosa = new Comida("Bebida","Gaseosa",4000f);
      Comida cerveza = new Comida("Bebida","Cerveza",7000f);
      Comida fresasconcrema = new Comida("Postre","Fresas con crema",9000f);
      Comida brownieconhelado = new Comida("Postre","Brownie con Helado",7000f);
      Comida churros = new Comida("Postre","Churros",8000f);
      
      
       while (!user.loged){
           System.out.println("Clave O Usuario Incorrecto, vuelva a intentarlo");
           user.login();
       }
       
       while (true) {
           float valor;
           int cantidad;
           String menu = "Seleccione lo que ordenaron: " + "\n"
                   + "1. Arepas" + "\n"
                   + "2. Papas fritas " + "\n"
                   + "3. Nachos" + "\n"
                   + "4. Churrasco" + "\n"
                   + "5. Pollo Frito" + "\n"
                   + "6. Arroz Oriental" + "\n"
                   + "7. Limonada" + "\n"
                   + "8. Gaseosa" + "\n"
                   + "9. Cerveza" + "\n"
                   + "10. Fresas con Crema" + "\n"
                   + "11. Brownie con Helado" + "\n"
                   + "12. Churros" + "\n"
                   + "13.  Salir";
           System.out.println(menu);
           int seleccion;
           seleccion = input.nextInt();
           if (seleccion == 1) {
               System.out.println("Cuantas arepas compraron?");
               cantidad = input.nextInt();
               mesa1.cuenta = mesa1.cuenta + arepas.precioCantidad(cantidad);
               
           }   else if (seleccion == 2) {
               System.out.println("Cuantas papas fritas compraron?");
               cantidad = input.nextInt();
               mesa1.cuenta = mesa1.cuenta + papasfritas.precioCantidad(cantidad);
               
           }   else if (seleccion == 3) {
               System.out.println("Cuantos nachos compraron?");
               cantidad = input.nextInt();
               mesa1.cuenta = mesa1.cuenta + nachos.precioCantidad(cantidad);
               
           }   else if (seleccion == 4) {
               System.out.println("Cuantos churrascos compraron?");
               cantidad = input.nextInt();
               mesa1.cuenta = mesa1.cuenta + churrasco.precioCantidad(cantidad);
               
           }   else if (seleccion == 5) {
               System.out.println("Cuantos pollos fritos compraron?");
               cantidad = input.nextInt();
               mesa1.cuenta = mesa1.cuenta + pollofrito.precioCantidad(cantidad);
               
           }   else if (seleccion == 6) {
               System.out.println("Cuantos arroces orientales compraron?");
               cantidad = input.nextInt();
               mesa1.cuenta = mesa1.cuenta + arrozoriental.precioCantidad(cantidad);
               
           }   else if (seleccion == 7) {
               System.out.println("Cuantas limonadas compraron?");
               cantidad = input.nextInt();
               mesa1.cuenta = mesa1.cuenta + limonada.precioCantidad(cantidad);
               
           }   else if (seleccion == 8) {
               System.out.println("Cuantas gaseosas compraron?");
               cantidad = input.nextInt();
               mesa1.cuenta = mesa1.cuenta + gaseosa.precioCantidad(cantidad);
               
           }   else if (seleccion == 9) {
               System.out.println("Cuantas cervezas compraron?");
               cantidad = input.nextInt();
               mesa1.cuenta = mesa1.cuenta + cerveza.precioCantidad(cantidad);
           }   else if (seleccion == 10) {
               System.out.println("Cuantas fresas con crema compraron?");
               cantidad = input.nextInt();
               mesa1.cuenta = mesa1.cuenta + fresasconcrema.precioCantidad(cantidad);
               
           }   else if (seleccion == 11) {
               System.out.println("Cuantos brownies con helado compraron?");
               cantidad = input.nextInt();
               mesa1.cuenta = mesa1.cuenta + brownieconhelado.precioCantidad(cantidad);
               
           }   else if (seleccion == 12) {
               System.out.println("Cuantos churros compraron?");
               cantidad = input.nextInt();
               mesa1.cuenta = mesa1.cuenta + churros.precioCantidad(cantidad);
           }
           if (seleccion == 13) {
               mesa1.cuentaIVA();
               break;
           } 
       }

    }
    
}
