/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial;

/**
 *
 * @author camil
 */
public class Mesa {
    
    int numero;
    float cuenta;
    float cuentaTotal;
    
    public Mesa(int numero) {
        this.numero = numero;
        this.cuenta = 0f;
    }
   
    public void cuentaIVA() {
        this.cuentaTotal = this.cuenta + ((this.cuenta * 19)/100);
        System.out.println("La cuenta total a pagar con IVA es de: " + this.cuentaTotal);
    }
    
    
}
