/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial;

/**
 *
 * @author camil
 */
public class Comida {
    String tipo;
    String producto;
    float precio;
    
    public Comida (String tipo, String producto, float precio) {
        this.tipo = tipo;
        this.producto = producto;
        this.precio = precio;
    }
    
    public float precioCantidad(int cantidad) {
        float precioTotal;
        precioTotal = this.precio * cantidad;
        
        return precioTotal;
    }
    
}
