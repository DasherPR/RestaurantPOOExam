/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial;
import java.util.Scanner;
/**
 *
 * @author camil
 */
public class Usuario {
    String savedusername = "Restaurante";
    String savedpassword = "Uean123";
    Scanner input = new Scanner(System.in);
    boolean loged;
   
    
    public void login () {
        String username;
        String password;
        System.out.println("Ingrese el nombre de usuario: ");
        username = input.next();
        System.out.println("Ingrese la clave: ");
        password = input.next();
        
        loged = username.equals(this.savedusername) & password.equals(this.savedpassword);
        
        System.out.println(loged); // este sout se puede quitar, es solo para probar si funcionaba
    }
    
}
